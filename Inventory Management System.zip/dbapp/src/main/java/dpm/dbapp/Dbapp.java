/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package dpm.dbapp;

/**
 *
 * @author sspmcoe
 */
public class Dbapp {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
